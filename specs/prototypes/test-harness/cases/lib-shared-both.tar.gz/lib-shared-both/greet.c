#include "greet.h"
#include <stdio.h>
void greet(void) { printf("hello\n"); }

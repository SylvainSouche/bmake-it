%{
#include <stdio.h>
void yyerror(const char *s);
int yylex(void);
%}
%token NUM
%%
input: /* empty */ | input NUM { printf("got num\n"); } ;
%%
void yyerror(const char *s) { fprintf(stderr, "error: %s\n", s); }

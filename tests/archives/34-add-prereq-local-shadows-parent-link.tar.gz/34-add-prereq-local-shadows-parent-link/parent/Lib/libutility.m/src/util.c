#include "util.h"
const char *util_greet(void) { return "parent-lib"; }

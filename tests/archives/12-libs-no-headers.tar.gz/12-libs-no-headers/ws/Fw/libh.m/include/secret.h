void secret(void);

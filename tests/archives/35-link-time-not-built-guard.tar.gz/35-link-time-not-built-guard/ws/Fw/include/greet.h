void greet(void);

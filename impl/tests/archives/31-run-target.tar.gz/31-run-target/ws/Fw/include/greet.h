void greet(const char *name);
